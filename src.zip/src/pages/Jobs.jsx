// src/pages/Jobs.jsx
import { useEffect, useState } from "react";
import axios from "axios";
import JobForm from "../components/JobForm";

const Jobs = () => {
  const [jobs, setJobs] = useState([]);
  const [editingJob, setEditingJob] = useState(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  const API = "http://localhost:5000/jobs-db";

  const fetchJobs = async () => {
    setLoading(true);
    try {
      const res = await axios.get(API);
      setJobs(res.data);
    } catch (err) {
      console.error("Fetch Error:", err);
    } finally {
      setLoading(false);
    }
  };

  const addJob = async (newJob) => {
    try {
      if (editingJob) {
        const res = await axios.put(`${API}/${editingJob.id}`, newJob);
        setJobs(jobs.map((job) => (job.id === editingJob.id ? res.data : job)));
        setMessage("Job updated successfully");
      } else {
        const res = await axios.post(API, newJob);
        setJobs([...jobs, res.data]);
        setMessage("Job added successfully");
      }
      setEditingJob(null);
    } catch (err) {
      console.error("Submit Error:", err);
      setMessage("An error occurred");
    }
  };

  const deleteJob = async (id) => {
    try {
      await axios.delete(`${API}/${id}`);
      setJobs(jobs.filter((job) => job.id !== id));
      setMessage("Job deleted successfully");
    } catch (err) {
      console.error("Delete Error:", err);
      setMessage("An error occurred");
    }
  };

  const editJob = (job) => {
    setEditingJob(job);
  };

  useEffect(() => {
    fetchJobs();
  }, []);

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">💼 Manage Jobs</h2>

      {message && <p className="text-green-600 mb-4">{message}</p>}

      <JobForm onSubmit={addJob} initialData={editingJob} />

      {loading ? (
        <p className="mt-6 text-gray-600">Loading jobs...</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-6">
          {jobs.map((job) => (
            <div key={job.id} className="bg-gray-100 p-4 rounded shadow">
              <h3 className="text-lg font-semibold text-blue-700 mb-1">{job.title}</h3>
              <p className="text-sm text-gray-600 mb-1">📍 {job.location}</p>
              <p className="text-sm mb-1">📝 {job.description}</p>
              <p className="text-sm mb-1">🧠 Skills: {job.skills}</p>
              <p className="text-sm mb-2">📌 Status: {job.status}</p>
              <div className="flex gap-2">
                <button
                  onClick={() => editJob(job)}
                  className="px-3 py-1 bg-yellow-500 text-white rounded text-sm"
                >
                  Edit
                </button>
                <button
                  onClick={() => deleteJob(job.id)}
                  className="px-3 py-1 bg-red-600 text-white rounded text-sm"
                >
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Jobs;
