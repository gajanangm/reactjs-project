import { useEffect, useState } from "react";
import axios from "axios";

const Applicants = () => {
  const [applicants, setApplicants] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    resume: null,
    jobId: ""
  });

  useEffect(() => {
    const fetchData = async () => {
      const [jobsRes, applicantsRes] = await Promise.all([
        axios.get("http://localhost:5000/jobs-db"),
        axios.get("http://localhost:5000/applicants-db")
      ]);
      setJobs(jobsRes.data);
      setApplicants(applicantsRes.data);
    };
    fetchData();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const resumeURL = formData.resume ? URL.createObjectURL(formData.resume) : "";

    const payload = {
      name: formData.name,
      email: formData.email,
      resume: resumeURL,
      jobId: parseInt(formData.jobId),
      appliedAt: new Date().toISOString()
    };

    await axios.post("http://localhost:5000/applicants-db", payload);
    const updated = await axios.get("http://localhost:5000/applicants-db");
    setApplicants(updated.data);
    setFormData({ name: "", email: "", resume: null, jobId: "" });
  };

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">👥 Applicant List</h2>

      <form onSubmit={handleSubmit} className="space-y-4 mb-6">
        <input
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          placeholder="Full Name"
          className="w-full p-2 border rounded"
          required
        />
        <input
          value={formData.email}
          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
          placeholder="Email"
          className="w-full p-2 border rounded"
          type="email"
          required
        />
        <select
          value={formData.jobId}
          onChange={(e) => setFormData({ ...formData, jobId: e.target.value })}
          className="w-full p-2 border rounded"
          required
        >
          <option value="">Select Job</option>
          {jobs.map((job) => (
            <option key={job.id} value={job.id}>{job.title}</option>
          ))}
        </select>
        <input
          type="file"
          accept="application/pdf"
          onChange={(e) => setFormData({ ...formData, resume: e.target.files[0] })}
          className="w-full p-2 border rounded"
          required
        />
        <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded">
          Submit Application
        </button>
      </form>

      <ul className="space-y-4">
        {applicants.map((applicant) => (
          <li key={applicant.id} className="p-4 border rounded shadow">
            <h3 className="text-lg font-semibold">{applicant.name}</h3>
            <p className="text-sm text-gray-600">{applicant.email}</p>
            <p className="text-sm">Applied for: {jobs.find((j) => j.id === applicant.jobId)?.title || "Unknown"}</p>
            <p className="text-sm">Applied At: {new Date(applicant.appliedAt).toLocaleString()}</p>
            {applicant.resume && (
              <a
                href={applicant.resume}
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 underline"
              >
                View Resume
              </a>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Applicants;
