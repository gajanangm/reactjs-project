import { useEffect, useState } from "react";

const Settings = () => {
  const [adminName, setAdminName] = useState("");
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    const savedName = localStorage.getItem("adminName");
    if (savedName) setAdminName(savedName);
  }, []);

  const handleSave = () => {
    localStorage.setItem("adminName", adminName);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="flex-1 p-4">
      <h2 className="text-2xl font-bold mb-6">⚙️ Settings</h2>

      <label className="block mb-2 font-semibold">Admin Name</label>
      <input
        value={adminName}
        onChange={(e) => setAdminName(e.target.value)}
        placeholder="Enter your name"
        className="w-full p-2 border rounded mb-4"
      />

      <button onClick={handleSave} className="px-4 py-2 bg-green-600 text-white rounded">
        Save Settings
      </button>

      {saved && <p className="text-green-600 mt-2">Settings saved successfully!</p>}

      {adminName && (
        <p className="mt-6 text-lg">👋 Hello, <span className="font-semibold">{adminName}</span>!</p>
      )}
    </div>
  );
};

export default Settings;
