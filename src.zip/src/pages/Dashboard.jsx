import { useEffect, useState } from "react";
import axios from "axios";
import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

const Dashboard = () => {
  const [jobs, setJobs] = useState([]);
  const [applicants, setApplicants] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const jobsRes = await axios.get("http://localhost:5000/jobs-db");
      const applicantsRes = await axios.get("http://localhost:5000/applicants-db");
      setJobs(jobsRes.data);
      setApplicants(applicantsRes.data);
    };
    fetchData();
  }, []);

  const jobStatusData = [
    {
      name: "Open",
      value: jobs.filter((j) => j.status === "Open").length,
    },
    {
      name: "Closed",
      value: jobs.filter((j) => j.status === "Closed").length,
    },
  ];

  const COLORS = ["#00C49F", "#FF8042"];

  return (
    <div>
      <h2 className="text-2xl font-bold mb-6">📊 Dashboard Overview</h2>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        <div className="bg-gray-800 p-6 rounded shadow text-center">
          <h3 className="text-xl font-semibold text-white">Total Jobs</h3>
          <p className="text-3xl font-bold text-white">{jobs.length}</p>
        </div>
        <div className="bg-gray-800  p-6 rounded shadow text-center">
          <h3 className="text-xl font-semibold text-white">Total Applicants</h3>
          <p className="text-3xl font-bold text-green-600">{applicants.length}</p>
        </div>
        <div className="bg-gray-800  p-6 rounded shadow text-center">
          <h3 className="text-xl font-semibold text-white">Jobs by Status</h3>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie
                data={jobStatusData}
                cx="50%"
                cy="50%"
                outerRadius={60}
                fill="#8884d8"
                dataKey="value"
                label
              >
                {jobStatusData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <h2 className="text-xl font-bold mb-4">📝 Job Listings</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {jobs.map((job) => (
          <div key={job.id} className="bg-gray-100 border rounded shadow p-5">
            <h3 className="text-lg font-bold text-gray-800 mb-1">{job.title}</h3>
            <p className="text-sm font-semibold text-gray-500 mb-1">📍 {job.location}</p>
            <p className="text-sm text-gray-600 mb-1">{job.description}</p>
            <p className="text-sm text-gray-600">Skills: {job.skills}</p>
            <span className={`inline-block mt-2 px-2 py-1 text-xs rounded ${job.status === "Open" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}>
              {job.status}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;