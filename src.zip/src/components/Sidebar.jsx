import { NavLink } from "react-router-dom";
import { useState } from "react";
import { Menu, X, Briefcase, LayoutDashboard, Users, Settings } from "lucide-react";

const Sidebar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const toggleSidebar = () => setIsOpen(!isOpen);

  const closeOnMobile = () => {
    if (window.innerWidth < 768) setIsOpen(false);
  };

  const linkStyle = (isActive) =>
    `px-3 py-2 rounded text-sm font-medium flex items-center gap-2 ${
      isActive ? "bg-yellow-400 text-black" : "hover:bg-gray-700"
    }`;

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div
          onClick={toggleSidebar}
          className="fixed inset-0 bg-black bg-opacity-50 z-40 md:hidden"
        ></div>
      )}

      {/* Mobile toggle button */}
      <div className="md:hidden p-4 z-50 relative">
        <button
          onClick={toggleSidebar}
          className="text-white bg-gray-800 p-2 rounded"
        >
          {isOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Sidebar */}
      <div
        className={`fixed md:static top-0 left-0 z-50 w-64 h-screen bg-gray-800 text-white p-4 transform transition-transform duration-300 ${
          isOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
        }`}
      >
        <h2 className="text-2xl font-bold mb-6">Admin Dashboard</h2>
        <nav className="flex flex-col gap-2">
          <NavLink to="/" onClick={closeOnMobile} className={({ isActive }) => linkStyle(isActive)}>
            <LayoutDashboard size={18} /> Dashboard
          </NavLink>
          <NavLink to="/jobs" onClick={closeOnMobile} className={({ isActive }) => linkStyle(isActive)}>
            <Briefcase size={18} /> Jobs
          </NavLink>
          <NavLink to="/applicants" onClick={closeOnMobile} className={({ isActive }) => linkStyle(isActive)}>
            <Users size={18} /> Applicants
          </NavLink>
          <NavLink to="/settings" onClick={closeOnMobile} className={({ isActive }) => linkStyle(isActive)}>
            <Settings size={18} /> Settings
          </NavLink>
        </nav>
      </div>
    </>
  );
};

export default Sidebar;
