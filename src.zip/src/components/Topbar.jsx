import { useState } from "react";
import { useNavigate } from "react-router-dom";

const Topbar = () => {
  const [darkMode, setDarkMode] = useState(false);
  const navigate = useNavigate();

  const toggleTheme = () => {
    setDarkMode(!darkMode);
    document.documentElement.classList.toggle("dark");
  };

  const handleLogout = () => {
    localStorage.removeItem("loggedIn");
    navigate("/login");
  };

  return (
    <div className="flex justify-between items-center px-6 py-4 bg-white dark:bg-gray-900 shadow-md sticky top-0 z-10">
      <div className="text-xl font-semibold text-gray-700 dark:text-white">Welcome Admin</div>
      <div className="flex items-center gap-4">
        <button
          onClick={toggleTheme}
          className="bg-gray-200 dark:bg-gray-700 p-2 rounded-full text-gray-800 dark:text-white"
        >
          🌓
        </button>
        <button
          onClick={handleLogout}
          className="px-3 py-1 bg-red-600 text-white rounded"
        >
          Logout
        </button>
      </div>
    </div>
  );
};

export default Topbar;