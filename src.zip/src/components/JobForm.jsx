import { useForm } from "react-hook-form";
import { useEffect } from "react";

const JobForm = ({ onSubmit, initialData }) => {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm();

  useEffect(() => {
    if (initialData) {
      reset(initialData);
    }
  }, [initialData, reset]);

  const submitForm = (data) => {
    onSubmit(data);
    reset();
  };

  return (
    <form onSubmit={handleSubmit(submitForm)} className="space-y-4">
      <input
        {...register("title", { required: "Title is required" })}
        placeholder="Job Title"
        className="w-full p-2 border rounded"
      />
      {errors.title && <p className="text-red-500 text-sm">{errors.title.message}</p>}

      <textarea
        {...register("description", { required: "Description is required" })}
        placeholder="Job Description"
        className="w-full p-2 border rounded"
      />
      {errors.description && <p className="text-red-500 text-sm">{errors.description.message}</p>}

      <input
        {...register("location", { required: "Location is required" })}
        placeholder="Location"
        className="w-full p-2 border rounded"
      />
      {errors.location && <p className="text-red-500 text-sm">{errors.location.message}</p>}

      <input
        {...register("skills", { required: "Skills are required" })}
        placeholder="Skills (comma separated)"
        className="w-full p-2 border rounded"
      />
      {errors.skills && <p className="text-red-500 text-sm">{errors.skills.message}</p>}

      <select {...register("status", { required: true })} className="w-full p-2 border rounded">
        <option value="">Select Status</option>
        <option value="Open">Open</option>
        <option value="Closed">Closed</option>
      </select>
      {errors.status && <p className="text-red-500 text-sm">Status is required</p>}

      <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded">
        {initialData ? 'Update Job' : 'Add Job'}
      </button>
    </form>
  );
};

export default JobForm;